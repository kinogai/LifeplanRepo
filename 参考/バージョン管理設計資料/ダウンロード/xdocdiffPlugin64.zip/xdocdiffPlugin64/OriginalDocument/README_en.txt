Install
Before installing:
Install WinMerge
Select [Plugins]-[Automatic Unpacking].

1. Unzip file.
2. Copy xdoc2txt.exe and zlib.dll to WinMerge program folder. (Where WinMerge.exe is located)
3. Copy amb_xdocdiffPlugin.dll to sub folder "MergePlugins".


Musee d'Dimanche
http://freemind.s57.xrea.com/
